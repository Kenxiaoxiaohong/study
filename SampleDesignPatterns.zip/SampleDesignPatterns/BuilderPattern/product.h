#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>

using namespace std;

// ����,��Ʒ��
class Computer
{
public:
	void SetmCpu(string cpu){m_strCpu = cpu;}
	void SetmMainboard(string mainboard){m_strMainboard = mainboard;}
	void SetmRam(string ram){m_strRam = ram;}
	void SetmVideoCard(string videoCard){m_strVideoCard = videoCard;}

	string GetCpu(){return m_strCpu;}
	string GetMainboard(){return m_strMainboard;}
	string GetRam(){return m_strRam;}
	string GetVideoCard(){return m_strVideoCard;}

private:
	string m_strCpu;	//Cpu
	string m_strMainboard; // ����
	string m_strRam;	// �ڴ�
	string m_strVideoCard;// �Կ�
};

#endif