#include "concrete_handler.h"

#ifndef SAFE_DELETE
#define SAFE_DELETE(p) {if(p){delete(p);(p)=NULL;}}
#endif // !SAFE_DELETE

int main()
{
	IHandler *manager = new Manager();
	IHandler *director = new Director();
	IHandler *ceo = new CEO();

	// ְ���������� -> �ܼ� -> �ܲ�
	manager->SetSuccessor(director);
	director->SetSuccessor(ceo);

	manager->HandlerRequest(1);
	manager->HandlerRequest(2);
	manager->HandlerRequest(5);
	manager->HandlerRequest(10);

	SAFE_DELETE(ceo);
	SAFE_DELETE(director);
	SAFE_DELETE(manager);

	getchar();

	return 0;
}
