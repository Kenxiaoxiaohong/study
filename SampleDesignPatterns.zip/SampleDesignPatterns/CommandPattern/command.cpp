//#include "command.h"
//#include "reciever.h"
//
//Command::Command(IReciever *reciever)
//	:m_pReciever(reciever)
//{}
//
//// �ӷ�
//AddCommand::Command(IReciever *reciever)
//	:Command(reciever)
//{}
//
//int AddCommand::execute()
//{
//	m_pReciever->setAction(TYPES::ACTION::ADD);
//	return m_pReciever->getResult();
//}
//
//// ����
//SubtractCommand::SubtractCommand(IReciever *reciever)
//    : Command(reciever)
//{
//
//}
//
//int SubtractCommand::execute()
//{
//    m_pReciever->setAction(TYPES::ACTION::SUBTRACT);
//    return m_pReciever->getResult();
//}
//
//// �˷�
//MultiplyCommand::MultiplyCommand(IReciever *reciever)
//    : Command(reciever)
//{
//
//}
//
//int MultiplyCommand::execute()
//{
//    m_pReciever->setAction(TYPES::ACTION::MULTIPLY);
//    return m_pReciever->getResult();
//}
//
//// ����
//DivideCommand::DivideCommand(IReciever *reciever)
//    : Command(reciever)
//{
//
//}
//
//int DivideCommand::execute()
//{
//    m_pReciever->setAction(TYPES::ACTION::DIVIDE);
//    return m_pReciever->getResult();
//}

#include "command.h"
#include "reciever.h"
#include <iostream>

Command::Command(Reciever *reciever)
	:m_pReciever(reciever)
{}


// ��
TakeCommand::Command(Reciever *reciever)
	:Command(reciever)
{}

TakeCommand::execute()
{
	std::cout << "Take command..." << std::endl;
	m_pReciever->takeOrder();
}

// ����
PayCommand::PayCommand(Reciever *reciever)
    : Command(reciever)
{

}

void PayCommand::execute()
{
    std::cout << "Pay command..." << std::endl;
    m_pReciever->receipt();
}