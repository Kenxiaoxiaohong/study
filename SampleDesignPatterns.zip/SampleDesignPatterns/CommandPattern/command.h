//#ifndef COMMAND_H
//#define COMMAND_H
//
//class IReciever;
//
//// �ṩִ������Ľӿ�
//class Command
//{
//public:
//    Command(IReciever *reciever);
//    virtual int execute() = 0;  // ִ������
//protected:
//    IReciever *m_pReciever;
//};
//
//// �ӷ�
//class AddCommand : public Command
//{
//public:
//    AddCommand(IReciever *reciever);
//    int execute();
//};
//
//// ����
//class SubtractCommand : public Command
//{
//public:
//    SubtractCommand(IReciever *reciever);
//    int execute();
//};
//
//// �˷�
//class MultiplyCommand : public Command
//{
//public:
//    MultiplyCommand(IReciever *reciever);
//    int execute();
//};
//
//// ����
//class DivideCommand : public Command
//{
//public:
//    DivideCommand(IReciever *reciever);
//    int execute();
//};
//
//#endif // COMMAND_H


#ifndef COMMAND_H
#define COMMAND_H

class Reciever;

// �ṩִ������Ľӿ�
class Command
{
public:
	Command(Reciever *reciever);
	virtual void execute()=0;// ִ������
protected:
	Reciever *m_pReciever;
};

// ��
class TakeCommand:public Command
{
public:
	TakeCommand(Reciever *reciever);
	void execute();
};

// ����
class PayCommand:public Command
{
public:
	PayCommand(Reciever *reciever);
	void execute();
};

#endif // !COMMAND_H
