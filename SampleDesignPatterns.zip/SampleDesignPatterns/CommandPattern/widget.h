#ifndef  WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "reciever.h"
#include "command.h"


#endif // ! WIDGET_H
