#ifndef COMMAND_H
#define COMMAND_H

class Reciever;

// �ṩִ������Ľӿ�
class Command
{
public:
    Command(Reciever *reciever);
    virtual void execute() = 0;  // ִ������
protected:
    Reciever *m_pReciever;
};

// ��
class TakeCommand : public Command
{
public:
    TakeCommand(Reciever *reciever);
    void execute();
};

// ����
class PayCommand : public Command
{
public:
    PayCommand(Reciever *reciever);
    void execute();
};

#endif // COMMAND_H