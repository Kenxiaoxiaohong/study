#include "reciever.h"
#include <iostream>

// �ӵ�
void Reciever::takeOrder()
{
    std::cout << "Take order..." << std::endl;
}

// �տ�
void Reciever::receipt()
{
    std::cout << "Receipt..." << std::endl;
}