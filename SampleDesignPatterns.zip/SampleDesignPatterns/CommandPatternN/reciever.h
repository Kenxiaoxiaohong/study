#ifndef RECIEVER_H
#define RECIEVER_H

// ˾��
class Reciever
{
public:
    void takeOrder();  // �ӵ�
    void receipt();  // �տ�
};

#endif // RECIEVER_H