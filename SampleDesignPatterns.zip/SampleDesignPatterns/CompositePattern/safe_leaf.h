#ifndef SAFE_LEAF_H
#define SAFE_LEAF_H

#include "safe_component.h"

class safe_leaf:public safe_component
{
public:
	safe_leaf(string name):safe_component(name){}
	virtual ~safe_leaf(){}
	void Operation(int indent){
		string newStr(indent,'-');
		cout<<newStr<<" "<<m_strName<<endl;
	}

private:
	safe_leaf();// ������
};
#endif