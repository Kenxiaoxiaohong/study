//װ����ģʽ

#include "concrete_component.h"
#include "concrete_decorator.h"
#include <iostream>

#ifndef SAFE_DELETE
#define SAFE_DELETE(p) {if(p){delete(p);p=NULL;}}
#endif

int main()
{
	/********** �ڿ��� **********/
	IBeverage *pHouseBlend = new HouseBlend();
	cout << pHouseBlend->Name() <<":"<<pHouseBlend->Cost()<<endl;

	// �ڿ��� + ����
	CondimentDecorator *pCream = new Cream(pHouseBlend);
	cout<<pCream->Name()<<":"<<pCream->Cost()<<endl;

	// �ڿ��� + Ħ��
	CondimentDecorator *pMocha = new Mocha(pHouseBlend);
	cout<<pMocha->Name()<<":"<<pMocha->Cost()<<endl;

	// �ڿ��� + �ǽ�
	CondimentDecorator *pSyrup = new Syrup(pHouseBlend);
	cout<<pSyrup->Name()<<":"<<pSyrup->Cost()<<endl;

	/********** ��Ⱥ��࿧�ȶ� **********/
	IBeverage *pDarkRoast = new DarkRoast();
	cout<<pDarkRoast->Name()<<":"<<pDarkRoast->Cost()<<endl;

	// ��Ⱥ��࿧�ȶ� + ����
	CondimentDecorator *pCreamDR = new Cream(pDarkRoast);
	cout<<pCreamDR->Name()<<":"<<pCreamDR->Cost()<<endl;

	// ��Ⱥ��࿧�ȶ� + ���� + Ħ��
	CondimentDecorator *pCreamMocha = new Mocha(pCreamDR);
	cout<<pCreamMocha->Name()<<":"<<pCreamMocha->Cost()<<endl;

	// ��Ⱥ��࿧�ȶ� + ���� + Ħ�� + �ǽ�
	CondimentDecorator *pCreamMochaSyrup = new Syrup(pCreamMocha);
	cout<<pCreamMochaSyrup->Name()<<":"<<pCreamMochaSyrup->Cost()<<endl;

	SAFE_DELETE(pCreamMochaSyrup);
	SAFE_DELETE(pCreamMocha);
	SAFE_DELETE(pCreamDR);
	SAFE_DELETE(pDarkRoast);

	SAFE_DELETE(pSyrup);
	SAFE_DELETE(pMocha);
	SAFE_DELETE(pCream);
	SAFE_DELETE(pHouseBlend);

	getchar();

	return 0;
}