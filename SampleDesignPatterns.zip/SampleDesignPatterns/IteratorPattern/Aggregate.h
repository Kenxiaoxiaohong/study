#ifndef AGGREGATE_H
#define AGGREGATE_H

#include "Iterator.h"

template <class Item>
class Aggregate
{
public:
	virtual Iterator<Item>* createIterator()=0;
	virtual ~Aggregate(){}
};
#endif // !AGGREGATE_H
