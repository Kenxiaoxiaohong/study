#include <vector>
#include "Aggregate.h"

template <class Item>
class ConcreteAggregate:public Aggregate
{
	vector<Item> data;
public:
	ConcreteAggregate<Item>()
	{
		data.push_back(1);
		data.push_back(2);
		data.push_back(3);
	}
	virtual Iterator<Item>* createIterator()
	{
		return new ConcreteAggregate<Item> (this);
	}
	Item& operator[] (int index){
		return data[index];
	}
	int getLen(){
		return data.size();
	}
};
