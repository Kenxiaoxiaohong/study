#include "Iterator.h"

template <class Item>
class ConcreteIterator:public Iterator<Item>
{
	ConcreteAggregate<Item> *aggr;
	int cur;

public:
	ConcreteIterator(ConcreteAggregate<Item> *a):aggr(a),cur(0){}
	virtual void first(){
		cur = 0;
	}
	virtual void next(){
		if(cur < aggr->getLen())
			cur++;
	}
	virtual Item* currentItem(){
		if (cur < aggr->getLen())
			return &(*aggr)[cur];
		else
			return NULL;
	}
	virtual bool isDone(){
		return (cur >= aggr->getLen());
	}
};