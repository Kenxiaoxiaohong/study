#ifndef ITERATOR_H
#define ITERATOR_H

#include <iostream>

template <class Item>
class ConcreteAggregate;

template <class Item>
class Iterator
{
public:
	virtual void first()=0;
	virtual void next()=0;
	virtual Item* currentItem()=0;
	virtual bool isDone()=0;
	virtual ~Iterator(){}
};
#endif // !ITERATOR_H
