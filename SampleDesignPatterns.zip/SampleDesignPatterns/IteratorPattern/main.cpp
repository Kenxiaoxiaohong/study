#include "Aggregate.h"
#include <iostream>

using namespace std;

int main()
{
	Aggregate<int> *aggr = new ConcreteAggregate<int>();
	Iterator<int> *it = aggr->createIterator();

	for(it->first();!it->isDone();it->next())
	{
		cout <<"Iterator"<<endl;
		cout<<*(it->currentItem())<<endl;
	}

	delete aggr;
	delete it;
	getchar();
	return 0;
}