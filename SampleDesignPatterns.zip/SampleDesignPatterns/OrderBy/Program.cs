﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderBy
{
    class Program
    {
        static void Main(string[] args)
        {

            var collection = Enumerable.Range(-5, 11).Select(x => new { Original = x, Square = x * x });
            foreach (var element in collection)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("--------------------------");
            //collection = collection.OrderBy(x => x.Square).ThenBy(x => x.Original);

            collection = collection.OrderBy(x => x.Square);

            /*
            var collection = Enumerable.Range(-5, 11) //先构造-5到5的整数集合
                                       .Select(x => new { Original = x, Square = x * x })
									   // x = -5 -4 -3 -2 -1 0 1 2 3 4 5
									   //投影到一个包含原始数字及其平方的匿名类型
									   //后面，先按平方进行排序，再按原始数字进行排序
									   //用了匿名类型的ToString实现格式化
                                       .OrderBy(x => x.Square)
									   //执行x => x.Square
									   //{ Original = -5, Square = 25 }
									   //{ Original = -4, Square = 16 }
									   //{ Original = -3, Square = 9 }
									   //{ Original = -2, Square = 4 }
									   //{ Original = -1, Square = 1 }
									   //{ Original = 0, Square = 0 }
									   //{ Original = 1, Square = 1 }
									   //{ Original = 2, Square = 4 }
									   //{ Original = 3, Square = 9 }
									   //{ Original = 4, Square = 16 }
									   //{ Original = 5, Square = 25 }
									   
									   
 
                                       .ThenBy(x => x.Original);
									   //执行 x => x.Original
									   //{ Original = -5, Square = 25 }
									   //{ Original = -4, Square = 16 }
									   //{ Original = -3, Square = 9 }
									   //{ Original = -2, Square = 4 }
									   //{ Original = -1, Square = 1 }
									   //{ Original = 0, Square = 0 }
									   //{ Original = 1, Square = 1 }
									   //{ Original = 2, Square = 4 }
									   //{ Original = 3, Square = 9 }
									   //{ Original = 4, Square = 16 }
									   //{ Original = 5, Square = 25 }
					*/				   
//System.Linq.OrderedEnumerable<<>f__AnonymousType1<int,int>,int>
            foreach (var element in collection)
//先是foreach 后 collection 后 in in调用.Select 后.OrderBy 后 .ThenBy 后 var element
//var element的值为  后in 后var elements
//{ Original = 0, Square = 0 }
//{ Original = -1, Square = 1 }
//{ Original = 1, Square = 1 }
//{ Original = -2, Square = 4 }
//{ Original = 2, Square = 4 }
//{ Original = -3, Square = 9 }
//{ Original = 3, Square = 9 }
//{ Original = -4, Square = 16 }
//{ Original = 4, Square = 16 }
//{ Original = -5, Square = 25 }
//{ Original = 5, Square = 25 }
            {
                Console.WriteLine(element);
            }
            Console.ReadKey();
        }
    }
}
