//�򵥹���ģʽ

#include "factory.h"
#include "product.h"
#include <iostream>

using namespace std;

#ifndef SAFE_DELETE
#define SAFE_DELETE(p) {if(p){delete(p);(p)=NULL;}}
#endif

int main()
{
	// ����
	Factory *pFactory = new Factory();

	// ��������
	ICar *pCar = pFactory->CreateCar(Factory::CAR_TYPE::BENZ_CAR);
	std::cout<<pCar->Name()<<endl;

	SAFE_DELETE(pCar);

	// ��������
	pCar = pFactory->CreateCar(Factory::CAR_TYPE::BMW_CAR);
	cout<<pCar->Name()<<endl;

	SAFE_DELETE(pCar);

	// �µ�����
	pCar = pFactory->CreateCar(Factory::CAR_TYPE::AUDI_CAR);
	cout<<pCar->Name()<<endl;

	SAFE_DELETE(pCar);

	getchar();

	return 0;
}