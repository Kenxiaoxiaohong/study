#include "SingletonPattern.h"

//// ���� - ����ʽ

Singleton *Singleton::m_pSingleton = NULL;

Singleton *Singleton::GetInstance()
{
	if(m_pSingleton==NULL)
		m_pSingleton=new Singleton();

	return m_pSingleton;
}


//// ���� - ����ʽ
/*
Singleton *Singleton::m_pSingleton = new Singleton();

Singleton *Singleton::GetInstance()
{
	return m_pSingleton;
}
*/

//// ���� - ����ʽ��˫���� DCL ���ƣ�
/*
Singleton *Singleton::m_pSingleton = NULL;
mutex Singleton::m_mutex;

Singleton *Singleton::GetInstance()
{
	if (m_pSingleton == NULL){
		std::lock_guard<std::mutex> lock(m_mutex);
		if(m_pSingleton == NULL)
			m_pSingleton = new Singleton();
	}
	return m_pSingleton;
}
*/