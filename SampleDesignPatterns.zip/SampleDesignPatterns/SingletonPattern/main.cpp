//����ģʽ

#include "SingletonPattern.h"
#include <iostream>

using namespace std;

Singleton::GC Singleton::GC::gc;

int main()
{
	//Singleton single = Singleton::GetInstance();

	Singleton *pSingleton1 = Singleton::GetInstance();
	Singleton *pSingleton2 = Singleton::GetInstance();
	cout<<(pSingleton1==pSingleton2)<<endl;

	getchar();

	//Singleton::GetInstance().doSomething();  // OK
	//Singleton single = Singleton::GetInstance();  // Error ���ܱ���ͨ��

    //Singleton::GetInstance();
    //Singleton::GetInstance()->DestoryInstance();  // �ֶ��ͷ�

    return 0;
}