#ifndef CONCRETE_STATE_H
#define CONCRETE_STATE_H

#include "state.h"

class TrafficLights;

// ���
class RedLight:public IState
{
public:
	RedLight(TrafficLights* context);
	virtual void Handle() override;

private:
	TrafficLights* m_pContext;
};

// �̵�
class GreenLight:public IState
{
public:
	GreenLight(TrafficLights* context);
	virtual void Handle() override;

private:
	TrafficLights* m_pContext;
};

// �Ƶ�
class YellowLight:public IState
{
public:
	YellowLight(TrafficLights* context);
	virtual void Handle() override;

private:
	TrafficLights* m_pContext;
};
#endif // !CONCRETE_STATE_H
