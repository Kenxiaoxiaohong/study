#ifndef STATE_H
#define STATE_H

// �źŵƵ�״̬
class IState
{
public:
	virtual void Handle()=0;
};
#endif // !STATE_H
