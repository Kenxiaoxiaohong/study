#ifndef STRATEGY_H
#define STRATEGY_H

// ���в���
class IStrategy
{
public:
	virtual void Travel()=0;
};
#endif // !STRAYEGY_H
