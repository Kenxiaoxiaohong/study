//ģ�巽��ģʽ
#include "concrete_class.h"

#ifndef SAFE_DELETE
#define SAFE_DELETE(p) {if(p){delete(p);(p)=NULL;}}
#endif

int main()
{
	// ����У��
	Company *alibaba = new Alibaba();
	alibaba->Recruit();

	// ��ѶУ��
	Company *tencent = new Tencent();
	tencent->Recruit();

	SAFE_DELETE(alibaba);
	SAFE_DELETE(tencent);

	getchar();

	return 0;
}