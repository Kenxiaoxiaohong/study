#include <iostream>
using namespace std;

class Father
{
public:
	int m_fMember;

	void testFunc(){
		cout<<"Father testFunc "<<m_fMember<<endl;
	}

	virtual void testVFunc(){
		cout<<"Father testVFunc "<<m_fMember<<endl;
	}
	Father(){m_fMember=1;}
};

class Child:public Father
{
public:
	int m_cMember;
	Child(){m_cMember=2;}

	virtual void testVFunc(){
		cout<<"Child testVFunc "<<m_cMember<<":"<<m_fMember<<endl;
	}
	void testFunc(){
		cout<<"Child testFunc "<<m_cMember<<":"<<m_fMember<<endl;
	}
	void testNFunc(){
		cout<<"Child testNFunc "<<m_cMember<<":"<<m_fMember<<endl;
	}
};

int main()
{
	Father* realFather=new Father();
	Child* pFalseChild=(Child*)realFather;
	Father* pFalseFather=new Child();

	pFalseFather->testFunc();
	pFalseFather->testVFunc();

	pFalseChild->testFunc();
	pFalseChild->testVFunc();
	pFalseChild->testNFunc();

	return 0;
}