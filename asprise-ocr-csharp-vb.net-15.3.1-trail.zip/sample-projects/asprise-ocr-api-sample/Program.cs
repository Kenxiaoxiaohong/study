﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using asprise_ocr_api;

namespace asprise_ocr_api_sample
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new OcrSampleForm());
        }

        public static void PerformOcrProgrammatically() {
            AspriseOCR.SetUp(); // one-time setup
            AspriseOCR ocr = new AspriseOCR();
            ocr.StartEngine(AspriseOCR.LANGUAGE_ENG);

            // recognize text from existing files ...
            string result1 = ocr.Recognize("C:\\path\\img.jpg", -1, -1, -1, -1, -1, AspriseOCR.RECOGNIZE_TYPE_ALL, AspriseOCR.OUTPUT_FORMAT_PLAINTEXT);

            // recognize text from in-memory images
            string result2 = ocr.Recognize(new List<Bitmap> { new Bitmap("img1.bmp"), new Bitmap("img2.png") }, -1, -1, -1, -1, AspriseOCR.RECOGNIZE_TYPE_ALL, AspriseOCR.OUTPUT_FORMAT_PLAINTEXT);
            
            // stop engine only if you don't need if any more
            ocr.StopEngine();
        }
    }
}